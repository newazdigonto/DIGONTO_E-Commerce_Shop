=== Theme Freesia Demo Import ===
Contributors: Theme Freesia
Requires at least: 5.7
Tested up to: 5.8.1
Stable tag: 2.0
License: GPLv3 or later
Tags: WordPress, vast, import, content, demo, data, widgets, settings, theme options

@ -46,6 +46,9 @@ Use Theme Freesia Demo importer plugins to import theme demo data with just a si
	Source: https://github.com/awesomemotive/theme-freesia-demo-import

== Changelog ==
= 2.0 =
	- Update - Updated files from One click demo import

= 1.0.5 =
	- Update - Zon dummy content added

= 1.0.4 =
	- fix - PHP 8.0 Warning: __wakeup() must have public visibility